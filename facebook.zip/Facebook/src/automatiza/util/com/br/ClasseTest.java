package automatiza.util.com.br;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;



public class ClasseTest {
	private WebDriver driver;
	@Before
	public void inicializa(){

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Zarp\\workspace\\Ecomerce\\resources\\chromedriver.exe");
		this.driver = new ChromeDriver(capabilities);
		driver.manage().window().maximize();
	}
	
	@Test
	public void logarFacebook(){
		Login login = new Login(driver);
		login.publicarNoFacebook();
		//driver.quit();
	}
}
