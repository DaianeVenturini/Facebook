
package automatiza.util.com.br;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login {
	
	private WebDriver driver;
	private String email;
	private String pass;
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setSenha(String pass) {
		this.pass = pass;
	}
	

	public Login(WebDriver driver) {
		super();
		this.driver = driver;
		email = "daiane_venturine@hotmail.com";
		pass = "ninha9702caramelo";
		logarNoFacebook();
	}

	
	public void logarNoFacebook() {
		
		driver.get("https://pt-br.facebook.com/login/");
		
		WebElement emailWebElement = driver.findElement(By.id("email"));
		emailWebElement.sendKeys(email);
		
		WebElement senhaWebElement = driver.findElement(By.id("pass"));
		senhaWebElement.sendKeys(pass);
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.id("loginbutton")).click();
	}
	
	public void publicarNoFacebook(){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 10);
			WebElement elemento = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@name='xhpc_message']")));

			elemento.click();
			elemento.sendKeys("Hello World");
			
			WebElement BtnPublica= driver.findElement(By.cssSelector
					("button[data-testid='react-composer-post-button']"));
							BtnPublica.click();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	
		
		
	}
}