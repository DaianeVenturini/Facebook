package automatizateste.util.com.br;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginUsuario {
	
	private WebDriver driver;
	private String email;
	private String pass;
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setPass(String pass) {
		this.pass = pass;
	}


	
	public LoginUsuario(WebDriver driver) {
		super();
		this.driver = driver;
		email = "daiane_venturine@hotmail.com";
		pass = "ninha9702caramelo";
	}

	public void logarNoSistema() {
		
		driver.get("https://pt-br.facebook.com/login/");
		
		WebElement emailWebElement = driver.findElement(By.id("email"));
		emailWebElement.sendKeys(email);
		
		WebElement senhaWebElement = driver.findElement(By.id("pass"));
		senhaWebElement.sendKeys(pass);
		
		//Thread.sleep(500);
		driver.findElement(By.className("full-button")).click();
	}
}